## LICENCIA DE USO
---
Datos distribuidos bajo licencia [Creative Commons Atribución 4.0 Internacional](http://creativecommons.org/licenses/by/4.0/legalcode)

### Términos de la Licencia Creative Commons CC BY 4.0 (resumen)

DERECHOS


* **Compartir** - Copiar y redistribuir el material en cualquier medio o formato
* **Adaptar** - Remezclar, transformar y crear a partir del materialpara cualquier finalidad, incluso comercial.

CONDICIONES

* **Reconocimiento** - Debe reconocer adecuadamente la autoría, proporcionar un enlace a la licencia e indicar si se han realizado cambios. Puede hacerlo de cualquier manera razonable, pero no de una manera que sugiera que tiene el apoyo del licenciador o lo recibe por el uso que hace.
* **No hay restricciones adicionales** - No puede aplicar términos legales o medidas tecnológicas que legalmente restrinja realizar aquello que la licencia permite.

AVISOS

No tiene que cumplir con la licencia para aquellos elementos del material en el dominio público o cuando su utilización está permitida por la aplicación de una excepción o un límite.

No se dan garantías. La licencia puede no ofrecer todos los permisos necesarios para la utilización prevista. Por ejemplo, otros derechos como los de publicidad, privacidad, o los derechos morales pueden limitar el uso del material.

ADVERTENCIAS

Este resumen pone de relieve solo algunas de las características clave y de los términos de la licencia real. No es una licencia y no tiene valor legal. Debe revisar cuidadosamente todos los términos y condiciones de la licencia real antes de utilizar el material sujeto a la licencia.

TEXTO COMPLETO

El anterior resumen no sustituye a la licencia real, cuyo texto completo puede consultar [aquí](http://creativecommons.org/licenses/by/4.0/legalcode).

